<template lang="pug">
  .curso-main-container.creditos-vista
    BannerInterno(subTitulo="SÍNTESIS")
    .container.tarjeta.tarjeta--blanca.p-4.p-md-5
      p(data-aos="fade-up").mb-5 La Unidad 3: Evaluación y cierre de proyectos, ofrece una mirada crítica sobre las etapas finales del ciclo de vida de un proyecto, resaltando su importancia para garantizar la satisfacción de los interesados y la mejora continua. Esta unidad proporciona las herramientas necesarias para ejecutar el cierre administrativo y técnico, realizar el análisis postmortem, documentar las lecciones aprendidas y generar informes finales. Esta perspectiva práctica, asegura que los estudiantes desarrollen competencias claves para concluir proyectos de manera efectiva, evaluando su desempeño y fortaleciendo la gestión del conocimiento en futuros desarrollos.


      .row.justify-content-center
        .col-lg-12.mb-5
          figure.bg-color-sintesis.p-5.brounded
            img(src='@/assets/curso/sintesis.svg', alt='', data-aos="zoom-in")
</template>
