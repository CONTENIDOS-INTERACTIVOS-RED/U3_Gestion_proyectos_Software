<template lang="pug">
.curso-main-container.introduccion
  BannerInterno(subTitulo="Introducción")
  .container.tarjeta.tarjeta--blanca.p-4.p-md-5.mb-5.pb-md-0
    .row.justify-content-center.mb-5 
      .col-lg-4
        .bg-color-1.p-3.h-100.brounded.j1
          p(data-aos="fade-down").mb-0 La evaluación y cierre de proyectos, constituye una fase crítica dentro del ciclo de vida de la gestión de proyectos de #[i software], frecuentemente subestimada, pero que determina, en gran medida, el nivel de éxito global de la iniciativa. Durante esta etapa, se consolidan los resultados obtenidos, se verifica el cumplimiento de los objetivos establecidos inicialmente y se extraen valiosas lecciones que servirán como base para futuras iniciativas. Un cierre técnico no solamente formaliza la conclusión de las actividades, sino que también contribuye significativamente, al proceso de madurez organizacional en el ámbito de la gestión de proyectos de #[i software].  
                
      .col-lg-4.my-4.my-lg-0
        figure
          img.img-a.img-t(src='@/assets/curso/temas/1.png', alt='', data-aos="zoom-in")          
      .col-lg-4
        .bg-color-7.p-3.h-100.brounded.j1
          p(data-aos="fade-down").mb-0 Al finalizar esta unidad, se espera que pueda evaluar el rendimiento de un proyecto tras su finalización, mediante la implementación de métricas específicas y la generación de reportes estructurados que reflejen el grado de cumplimiento de los objetivos establecidos inicialmente. Adicionalmente, logrará identificar, documentar y aplicar las lecciones aprendidas durante el desarrollo, transformando las experiencias del proyecto en conocimiento organizacional valioso, que podrá aplicarse sistemáticamente en iniciativas futuras, contribuyendo así al proceso de mejora continua.

    .row.mb-5       
      .col-lg-8.mb-3.mb-lg-0
        .bg-color-2.p-4.mb-4(data-aos="fade-left")
          .row.align-items-start
            .col-lg-auto
              img.img-a.img-t(src="@/assets/curso/temas/2.svg")
            .col-lg
              p.mb-0 En el competitivo entorno profesional actual, dominar las técnicas de evaluación y cierre de proyectos representa una ventaja competitiva significativa para cualquier ingeniero de #[i software]. Las organizaciones reconocen cada vez más la importancia de implementar procesos estructurados para capitalizar el conocimiento generado durante sus proyectos, convirtiéndolo en un activo estratégico. 

        p(data-aos="fade-down") Los profesionales que desarrollan habilidades sólidas en estas áreas no solo mejoran sus perspectivas laborales, sino que también aportan un valor diferencial a sus organizaciones, convirtiéndose en agentes claves para la transformación y madurez de los procesos de gestión.

        h5(data-aos="fade-down") La presente unidad se ha estructurado en tres grandes bloques temáticos: 

      .col-lg-4
        figure
          img.img-a.img-t(src="@/assets/curso/temas/3.png", data-aos="zoom-in") 
    .bg-full-width-1.bg-fondo-1(data-aos="fade-right")
      .px-4.p-md-3
        .px-4
          div.row.justify-content-center.align-items-stretch.text-center
            div.col-lg-4.mb-4(data-aos="zoom-in-up")
              div.bg-color-white.box-shadow.p-3.h-100.br-1
                img.mx-auto.d-block.mb-4(src="@/assets/curso/temas/4.svg" alt="" style="width: 90px")
                h5 Primer bloque
                p.mb-0 Se explorará la generación de informes finales, analizando su estructura, contenido y relevancia para la formalización del cierre.
            div.col-lg-4.mb-4(data-aos="zoom-in-up")
              div.bg-color-white.box-shadow.p-3.h-100.br-1
                img.mx-auto.d-block.mb-4(src="@/assets/curso/temas/4.svg" alt="" style="width: 90px")
                h5 Segundo bloque
                p.mb-0 Se profundizará en el análisis postmortem como herramienta para evaluar críticamente el desempeño del proyecto desde múltiples perspectivas.
            div.col-lg-4.mb-4(data-aos="zoom-in-up")
              div.bg-color-white.box-shadow.p-3.h-100.br-1
                img.mx-auto.d-block.mb-4(src="@/assets/curso/temas/4.svg" alt="" style="width: 90px")
                h5 Tercer bloque
                p.mb-0 Se abordará la gestión de lecciones aprendidas, examinando cómo transformar las experiencias del proyecto en conocimiento aplicable que contribuya a la mejora continua de la organización.    

          p(data-aos="fade-down").mb-4 Se invita para que las habilidades desarrolladas, trasciendan el ámbito académico y se conviertan en competencias profesionales altamente valoradas en la industria. Asimismo, se recomienda contrastar los conceptos teóricos con experiencias previas o conocimientos adquiridos en otras asignaturas, estableciendo conexiones significativas que enriquezcan su comprensión global de la gestión de proyectos de #[i software].                      
</template>
