module.exports = 'Evaluación y cierre de proyectos'
